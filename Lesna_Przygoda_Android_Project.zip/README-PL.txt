LEŚNA PRZYGODA — projekt APK na Androida

Jak zbudować APK z telefonu:
1. Rozpakuj ZIP.
2. Wejdź na https://github.com i zaloguj się.
3. Utwórz nowe repozytorium (New repository), np. lesna-przygoda.
4. W repozytorium wybierz Add file -> Upload files.
5. Wgraj CAŁĄ zawartość tego folderu (w tym ukryty folder .github).
6. Zatwierdź przyciskiem Commit changes.
7. Otwórz zakładkę Actions. Wybierz workflow „Buduj APK”.
8. Jeśli nie uruchomił się sam, wybierz Run workflow.
9. Po zakończeniu zielonego zadania otwórz je i pobierz artefakt „Lesna-Przygoda-APK”.
10. Rozpakuj pobrany ZIP i zainstaluj app-debug.apk.

Gra działa poziomo, offline. Sterowanie:
- lewy joystick: ruch
- prawy joystick: obrót kamery
- ŚCINAJ: zetnij najbliższe drzewo
- SKOK: podskok
- sklep: kupuj mocniejsze siekiery

Uwaga: APK jest kompilowane jako debug APK. Android może poprosić o zgodę na instalację aplikacji z przeglądarki/pliku.
