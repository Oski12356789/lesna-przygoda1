package pl.oski.forestgame;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView view = new WebView(this);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        view.setBackgroundColor(0xFF79B85A);
        setContentView(view);
        view.loadUrl("file:///android_asset/game.html");
    }
    @Override public void onBackPressed() { super.onBackPressed(); }
}
