# Leśna Przygoda — Android
Projekt Android z grą HTML5 uruchamianą lokalnie w WebView. Wgraj zawartość ZIP do repozytorium GitHub (rozpakowaną, nie sam ZIP), a GitHub Actions zbuduje APK.
